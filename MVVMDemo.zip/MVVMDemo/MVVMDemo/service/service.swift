
import Foundation
import UIKit

//MARK:- Service class
class Service: NSObject{
    
    static let shareInstance = Service()
    
    //MARK:- Get data from api
    func getAllMovieData(completion: @escaping([modelmovie]?, Error?) -> ()){
        let urlString = "https://itunes.apple.com/search?media=music&term=bollywood"
        guard let url = URL(string: urlString) else { return }
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let err = error{
                completion(nil,err)
                print("Loading data error: \(err.localizedDescription)")
            }else{
                guard let data = data else { return }
                do{
                    var arrMovieData = [modelmovie]()
                    
                    // decode data
                    let result = try JSONDecoder().decode(ResultModel.self, from: data)
                    for movie in result.results{
                        // append models
                        arrMovieData.append(modelmovie(artistName: movie.artistName!, trackName: movie.trackName!, collectionName: movie.collectionName!))
                    }
                    completion(arrMovieData, nil)
                }catch let jsonErr{
                    print("json error : \(jsonErr.localizedDescription)")
                }
            }
        }.resume()
    }
}
