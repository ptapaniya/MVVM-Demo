
import Foundation
import UIKit

//MARK:- Movie model
class MovieModel:NSObject{
    var artistName : String?
    var trackName : String?
    var collectionName : String?
    
    init(movie: modelmovie){
        self.artistName = movie.artistName
        self.trackName = movie.trackName
        self.collectionName = movie.collectionName
    }
}
