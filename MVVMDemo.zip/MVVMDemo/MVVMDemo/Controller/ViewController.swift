
import UIKit

class ViewController: UIViewController {
    
    //MARK:- Outlets
    @IBOutlet weak var tableView: UITableView!
    
    //MARK:- Variables
    var arrMovieVM = [MovieModel]()
    
    //MARK:- Life-cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
    }
    
    //MARK:- Get data
    func getData(){
        Service.shareInstance.getAllMovieData { (movies, error) in
            if (error == nil){
                
                // convert records into models
                self.arrMovieVM = movies?.map({ return MovieModel(movie:  $0) }) ?? []
                DispatchQueue.main.async {
                    
                    // reload table
                    self.tableView.reloadData()
                }
            }
        }
    }
}

//MARK:- Tableview delegate-datasource
extension ViewController: UITableViewDelegate,UITableViewDataSource{
   
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrMovieVM.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MovieCell
        
        // fetch data from model
        let dict = self.arrMovieVM[indexPath.row]
        cell.artistName.text = dict.artistName
        cell.trackName.text = dict.trackName
        cell.collectionName.text = dict.collectionName
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        100
    }
}
