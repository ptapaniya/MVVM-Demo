
import Foundation
import UIKit

//MARK:- Moview model
class modelmovie:Decodable{
    var artistName : String?
    var trackName : String?
    var collectionName : String?
    
    
    init(artistName:String, trackName:String, collectionName:String){
        self.artistName = artistName
        self.trackName = trackName
        self.collectionName = collectionName
    }
}


class ResultModel:Decodable{
    var results =  [modelmovie]()
    
    init(results: [modelmovie]) {
        self.results = results
    }
}
